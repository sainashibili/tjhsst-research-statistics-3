# tjhsst-research-statistics-3
 projects from TJHSST's computational statistics course (RS3)
